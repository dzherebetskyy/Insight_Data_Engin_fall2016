// example of program that detects suspicious transactions
// fraud detection algorithm
